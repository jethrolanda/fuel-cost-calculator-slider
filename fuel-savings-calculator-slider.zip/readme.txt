=== Fuel Savings Calculator Slider ===
Contributors: jlanda
Donate link:
Tags: savings, calculator, slider
Requires at least: 4.2
Tested up to: 6.0
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== DESCRIPTION ==


***Key Features (Free Plugin):***

* List down key Features

== Changelog ==

= 1.0.0 =
* Initial version

== Upgrade notice ==

There is a new version of Fuel Savings Calculator Slider available.
